# Pinder > 2026-09-24 7:31am
https://universe.roboflow.com/charles-university/pinder

Provided by a Roboflow user
License: CC BY 4.0

